@extends('admin.layouts.master')
@section('content')
<section class="content">
<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
<script language="javascript">
	function load_employee(id){

		var url_str = "groupId="+id;

		$.ajax({
			type: "GET",
			url: "{{asset('admin/load_group_user')}}",
			data: url_str,
			success: function(data){
				$('#employee_div').html(data);
			}
		});
	}

	function load_event(id){
		var url_str = "appId="+id;
		$.ajax({
			type: "GET",
			url: "{{asset('admin/load_app_event')}}",
			data: url_str,
			success: function(data){
				$('#event_div').html(data);
			}
		});
	}
</script>

	<div class="row">
		<!-- left column -->
		<div class="col-md-12">
			<div class="box">
			<div class="box box-primary">
				<div class="box-header with-border">
					<h3 class="box-title">Customer Chat</h3>
				</div><!-- /.box-header -->
					<div class="box-body">
						<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.5/angular.min.js"></script>
						<body ng-app="myapp">
						<?php $i=0;?>

						<div class="box box-primary" style="padding:1%;">
							<div class="box-header with-border">
								<h3 class="box-title">Chat</h3>
							</div><!-- /.box-header -->
							<div class="tab-content">
								<div ng-controller="ChatController">
									<table border="1" width="100%" class="table table-bordered table-striped">
										<tr><th style="text-align:left;">ID</th><th style="text-align:left;">Email</th><th style="text-align:left;">Subject</th><th style="text-align:left;">Start Chat</th></tr>
										<tr ng-repeat="ch in chats">
											<td ng-bind="ch.id"></td><td ng-bind="ch.email"></td><td ng-bind="ch.subject"></td><td><a style="cursor:pointer;" class="hit" id="<%ch.id%>" onclick="startchat(this.id)">Start</a></td>
										</tr>
									</table>
								</div>
							</div>
						</div>
						<div style="clear:both;">&nbsp;</div>
							<script language="javascript">
								angular.module("myapp", [], function($interpolateProvider) {
									$interpolateProvider.startSymbol('<%');
									$interpolateProvider.endSymbol('%>');
								})
								.controller("ChatController", function($scope,$http,$interval,$timeout){
								$http.get("http://106.51.0.187:8000/Cricketgate_CRM_new/branches/public/admin/fetchchats",{
									headers:{
										'Content-type': 'application/json'
									}
								}).then(function(response){
									console.log(response.data);
									$scope.chats=response.data.chats;
									$scope.chatcount=response.data.chatcount;
									$interval(callAtTimeout, 5000);
								});

								function callAtTimeout(){
									$http.get("http://106.51.0.187:8000/Cricketgate_CRM_new/branches/public/admin/fetchchats",{
									headers:{
										'Content-type': 'application/json'
									}
									}).then(function(response){
										console.log(response.data);
										$scope.chats=response.data.chats;
										$scope.chatcount=response.data.chatcount;
									});
								}
							})
							.controller("TicketController", function($scope,$http,$interval,$timeout){
								$http.get("http://106.51.0.187:8000/Cricketgate_CRM_new/branches/public/admin/tick_cnt",{
									headers:{
										'Content-type': 'application/json'
									}
								}).then(function(response){
									console.log(response.data);
									$scope.opencount=response.data.open;
									$scope.onholdcount=response.data.onhold;
									$scope.closedcount=response.data.closed;
									$interval(callAtTimeout, 5000);
								});

								function callAtTimeout(){
									$http.get("http://106.51.0.187:8000/Cricketgate_CRM_new/branches/public/admin/tick_cnt", {
										headers:{
											'Content-type': 'application/json'
										}
									}).then(function(response){
									console.log(response.data);
										$scope.opencount=response.data.open;
										$scope.onholdcount=response.data.onhold;
										$scope.closedcount=response.data.closed;
									});
								}
							});
							</script>
						</body>
						</html>
						<!--chat window invoke script starts here-->
						<script src="{{asset('/chat/js/script.js')}}"></script>
						<style>
							.loginform{
								padding:10px;
								background:#3c8dbc;
								width:100%;
								z-index: 1000;
								position:fixed;
								right:0px;
								bottom:0px;
								color:white;
							}
							.chat{
								padding:10px;
								background:#3c8dbc;
								width:20%;
								/* position:fixed;
								right:20px; */
								bottom:0px;
								color:white;
								float:right;
								margin-right: 10px;
							}						
							.chatbox{
								text-align:left;
								margin:0 auto;
								margin-bottom:25px;
								padding:10px;
								background:#fff;
								height:200px;
								color:black;
								border:1px solid #ACD8F0;
								overflow:auto;
							}
						</style>
						<?php
							error_reporting(0);
							session_start();
						?>  
						
						<div class="loginform" id="chatContainer" style="background:transparent;">
						</div>

<script type='text/javascript' src="{{asset('/chat/js/jquery.js')}}"></script>
<script type='text/javascript' src="{{asset('/chat/js/jquery.simplemodal.js')}}"></script>
<script language="javascript">
	
	$(document).ready(function(){
	});
						
	function loadLog(filename){
		
		var cb_file = filename;
		var oldscrollHeight = $("#chatbox"+cb_file).attr("scrollHeight") - 20; //Scroll height before the request
		var str1 = "http://106.51.0.187:8000/Cricketgate_CRM_new/branches/public/chat/loghtml/log.";
		var str2 = "firstchat";
		var str3 = ".html";
		var filename =  "http://106.51.0.187:8000/Cricketgate_CRM_new/branches/public/chat/loghtml/log."+filename+".html";
		$.ajax({
			url: filename,
			cache: false,
			success: function(html){
				
				$("#chatbox"+cb_file).html(html); //Insert chat log into the #chatbox div
				var newscrollHeight = $("#chatbox"+cb_file).attr("scrollHeight") - 20; //Scroll height after the request
				if(newscrollHeight > oldscrollHeight){
					$("#chatbox"+cb_file).animate({ scrollTop: newscrollHeight }, 'normal'); //Autoscroll to bottom of div
				}
			},
		});
	}

	
	Array.remove = function(array, from, to) {
		var rest = array.slice((to || from) + 1 || array.length);
		array.length = from < 0 ? array.length + from : from;
		return array.push.apply(array, rest);
	};

	//this variable represents the total number of popups can be displayed according to the viewport width
	var total_popups = 0;
	
	//arrays of popups ids
	var popups = [];
	
	function startchat(id){
		
		for(var iii = 0; iii < popups.length; iii++)
		{   
			//already registered. Bring it to front.
			alert(iii);
			if(id == popups[iii])
			{
				Array.remove(popups, iii);
			
				popups.unshift(id);
				
				calculate_popups();
				
				return;
			}
		}
		var myInterval;
		clearInterval(myInterval);
		var url_str = "chatId="+id;

		$.ajax({
			type: "GET",
			url: "{{asset('admin/custchathisupd')}}",
			data: url_str,
			success: function(data){
				//$('#event_div').html(data);
				var result=data.split("~");
				$("#"+id).parents("tr").remove();
				$("#entryform").hide();
				$("#chatfile").val(result[0]);
				$("#name1").val(result[1]);
				
				loadLog(result[0]);

				myInterval=setInterval (function() { loadLog(result[0]); }, 2500);

				$("#chatContainer").append('<div onclick = "maxchat(this.id)" id="maxchat'+result[0]+'" style="height:30px;float:right;display:none;"><span style="width:50px;background:#333;padding:5px 10px 5px 10px;margin-right:5px;cursor:pointer">+</span></div>'
						+'<div class="chat" id="chat'+result[0]+'">'
							+'<div style="height:30px;float:right;clear:both;width:100%;text-align:right">'
								+'<span onclick = "minchat(this.id)" id="minchat'+result[0]+'" style="width:50px;background:#333;padding:5px 10px 5px 10px;margin-right:5px;cursor:pointer">-</span>'
								+'<span onclick = "closechat(this.id)" id="closechat'+result[0]+'" style="width:50px;background:#333;padding:5px 10px 5px 10px;cursor:pointer">X</span>'
							+'</div>'
							+'<div class="chatbox" id="chatbox'+result[0]+'"></div>'
							+'<div width="100%">'
								+'<input type="hidden" name="chatfile" id="chatfile" value="'+result[0]+'" />'
								+'<input type="text" id="msg1'+result[0]+'" style="color: #333;height:50px;width:84%;">'
								+'<input type="button" onclick = "chatsubmit(this.id)" style="background:#333 none repeat scroll 0 0;border:medium none; color: white;height: 50px;margin-left: 5px;" id="'+result[0]+'" value="submit">'
								+'<input type="hidden" name="name1" id="name1" value="'+result[0]+'">'
							+'</div>'
						+'</div>'
						);
				
				$("#chat"+result[0]).show("slow");
	
			}
		});
	}
	
	function chatsubmit(id){

		var str4 = "http://106.51.0.187:8000/Cricketgate_CRM_new/branches/public/chat/post.new.php";
		var streamname = "firstchat";
		var postfilename = str4.concat("?stream=",streamname);
		var clientmsg = $("#msg1"+id).val();
		var clientname = $("#name1").val();
		var filename = id;
		var rating = $("#rating").val();
		
		http://106.51.0.187:8000/Cricketgate_CRM_new/branches/public/chat/post.new.php?stream=firstchat
		
		if(clientmsg!=""){
			$.post(postfilename, {subject: clientmsg,usertype:'admin',name:clientname,rating:rating,type:'onhold',filename:filename},function( data ) {
				loadLog(filename);
			});
			$("#msg1"+id).attr("value", "");
			document.getElementById("msg1"+id).value = "";
			$("#msg1"+id).focus();
		}
		return false;			
	}

	function minchat(minid){
		
		var id = minid.replace("minchat", ""); 
		$("#chat"+id).hide("slow");
		$("#maxchat"+id).show();
	}

	function closechat(clsid){
		var id = clsid.replace("closechat", ""); 
		var res=confirm("Are you sure want to close?");
		if(res){
			$("#chat"+id).hide("slow");
			$("#maxchat"+id).hide();
			$.get( "closechat.php", function( data ) {
			});
		}
	}
	
	function maxchat(maxid){
		var id = maxid.replace("maxchat", ""); 
		$("#chat"+id).show("slow");
		$("#maxchat"+id).hide();
		$.get( "closechat.php", function( data ) {
		});
	}
	
</script>
						<!--chat window invoke script end here-->
@endsection