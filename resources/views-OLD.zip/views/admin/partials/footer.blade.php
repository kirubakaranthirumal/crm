</body>
<footer class="main-footer">
    <!-- To the right -->
    <!-- Default to the left -->
    <strong>Copyright © 2016 <a href="#">Follow On CRM</a>.</strong> All rights reserved.
</footer>
</html>