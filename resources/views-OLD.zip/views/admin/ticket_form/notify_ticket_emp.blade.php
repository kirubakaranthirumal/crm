<a href="#" class="dropdown-toggle" data-toggle="dropdown">
	<i class="fa fa-bell-o"></i>
	<span class="label label-warning"><?=(!empty($new_ticket_count)?$new_ticket_count:"0")?></span>
</a>
<ul class="dropdown-menu">
	<li class="header">
		<a href="{{asset('update_new_ticket_notify_emp')}}">You have <?=(!empty($new_ticket_count)?$new_ticket_count:"0")?> newly assigned ticket </a>
	</li>
</ul>
