@extends('admin.layouts.master')

@section('content')
        <section class="invoice">
          <!-- title row -->
          <div class="row">
            <div class="col-xs-12">
              <h2 class="page-header">
               <i class="fa fa-user" aria-hidden="true"></i> <span><b>User :</b>
               	@if(isset($userdata->userId))
					{{$userdata->userId}}
				@endif
               </span>
                  <!--<div class="pull-right" style="margin-right:16px;">
                  <a class="btn btn-success" href="{{asset('/admin/edit_user/')}}/@if(isset($userdata->userId)){{$userdata->userId}}@endif">Edit User</a>
                   <!--<a class="btn btn-success" href="{{ url(config('quickadmin.route').'/dept_transfer') }}">Dept Transfer</a>
                  </div>-->

              </h2>

            </div><!-- /.col -->
          </div>
          <!-- info row -->
          <div class="row invoice-info">
            <div class="col-sm-6 invoice-col">

              <!-- Profile Image -->
                  <ul class="list-group list-group-unbordered">
                    <li class="list-group-item" style="border-top:none;">
                      <b>Name</b> <a class="pull-right">@if((isset($userdata->firstName))&&(isset($userdata->lastName)))
              							{{$userdata->firstName}} {{$userdata->lastName}}
									@endif</a>
                    </li>
                    <li class="list-group-item">
                          <b>Email</b> <a class="pull-right">@if(isset($userdata->email))
				        				{{$userdata->email}}
              						@endif</a>
                    </li>
                    <li class="list-group-item">
                      <b>Gender</b> <a class="pull-right">
					 @if(isset($userdata->gender))
              							@if($userdata->gender==1)
              								Male
              							@elseif($userdata->gender==2)
              								Female
              							@endif
              						@endif</a>
                    </li>
				   <li class="list-group-item">
                      <b>Modified On</b> <a class="pull-right">
					  @if(isset($userdata->modifiedOn))
						     <?php
                          $date=date_create($userdata->modifiedOn);
                          echo date_format($date,"Y-m-d h:i A");
                          ?>
					  @endif
						</a>
                    </li>
					</ul>
            </div><!-- /.col -->
    <!-- /.col -->
            <div class="col-sm-6 invoice-col">
			          <ul class="list-group list-group-unbordered">
                    <li class="list-group-item" style="border-top:none;">
                      <b>Type</b> <a class="pull-right">@if(isset($userdata->userType))
						@if($userdata->userType==1)
							Admin
						@elseif($userdata->userType==2)
							Supervisior
						@elseif($userdata->userType==3)
							Employee
						@endif
						@endif
						</a>
                    </li>
                    <li class="list-group-item">
                          <b>Status</b> <a class="pull-right">@if(isset($userdata->status))
						@if($userdata->status==1)
							Active
						@elseif($userdata->status==2)
							In-Active
						@endif
					@endif
					</a>
                    </li>
                    <li class="list-group-item">
                      <b>Created On </b> <a class="pull-right">
					  @if(isset($userdata->createdOn))
						<?php
                          $date=date_create($userdata->createdOn);
                          echo date_format($date,"Y-m-d h:i A");
                          ?>
			  @endif</a>
                    </li>
				  
					</ul>
            </div><!-- /.col -->
                      </div><!-- /.row -->

                 <br>
          <div class="row">
          <div class="col-sm-8">
          	<!--<a class="btn btn-success" href="{{ url(config('quickadmin.route').'/dept_transfer') }}">Dept Transfer</a>-->
			</div>
          	</div>

          <!-- Table row -->
          <div class="row">
            <div class="col-xs-12 table-responsive">
   				     <div class="box-body">
				<div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">User History</h3>
                  </div>		 

				  @if(isset($logsdata))
                 	@foreach ($logsdata as $logs)
                      <div class="user-block">
                        <span class=''>
                          <span> @if(isset($logs->Date))
							  		<?php
                          $date=date_create($logs->Date);
                          echo date_format($date,"Y-m-d h:i A");
                          ?>
							@endif
						</span>
                        </span>
                        <br>
                        <span>
							<small><b>@if(isset($logs->UserAction))
							{{$logs->UserAction}}
							@endif</b> - @if(isset($logs->msg)){{$logs->msg}}@endif </small>
                        </span>
                      </div>
                      <br>
					  @endforeach 
					  @endif
              </div>

          </div><!-- /.row -->
          </div>
          </section>


@endsection