@extends('admin.layouts.master')

@section('content')
    <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">

<div class="box box-primary">
					<div class="box-header with-border">
                  <h3 class="box-title">Users</h3>
                </div><!-- /.box-header -->
				 @if (session('DeleteUserSuccess'))
					 <div class="col-md-12">
                <div class="flash-message">
                   <div class="alert alert-success">
                        User Deleted Successfully
						<script>
							window.setTimeout(function(){
							window.location.href = "{{asset('/admin/view_user/')}}";
							}, 1000);
						</script>
                  </div>
                </div>
				</div>
              @endif
                @if (session('DeleteUserError'))
					<div class="col-md-12">
                  <div class="flash-message">
                     <div class="alert alert-danger">
                      Cannot Update ticket
                    </div>
                  </div>
				  </div>
                @endif
           <div class="box-body">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>E-mail</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th>Last Logged</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                 @if(isset($userdata))
                 	@foreach ($userdata as $data)
                <tr>
                  <td>
					@if(isset($data->userId))
						{{$data->userId}}
					@endif
				  </td>
                  <td>
                  		@if(isset($data->firstName))
                  			{{ $data->firstName}}
                  		 @endif
                  		 @if(isset($data->lastName))
						    {{ $data->lastName}}
                  		 @endif
                  		</td>
                  <td>
                   @if(isset($data->email))
					{{ $data->email}}
                   @endif
                  </td>
                  <td>
                  @if(isset($data->userType))
                            @if($data->userType==1)
                              Admin
                            @elseif($data->userType==2)
                              Supervisor
                            @elseif($data->userType==3)
                              Employee
                            @endif
                          @endif</td>
                  <td>@if(isset($data->status))
                            @if($data->status==1)
                              Active
                            @elseif($data->status==2)
                              In-Active
                            @endif
                          @endif</td>
                  <td>
                  	@if(isset($data->createdOn))
                  		{{ $data->createdOn }}
                  	@endif
                  </td>
                  <td>
                  	@if(isset($data->userId))
						@if($data->userId!=1)
							<a href="{{asset('/admin/view_user/')}}/@if(isset($data->userId)){{ $data->userId}} @endif" title="delete">
								<i class="fa fa-remove"></i>
							</a> &nbsp;&nbsp;
							<a href="{{asset('/admin/edit_user/')}}/@if(isset($data->userId))
								{{ $data->userId}}
								@endif" title="edit">
								<i class="fa fa-edit"></i>
							</a> &nbsp;&nbsp;
							<a href="{{asset('/admin/user_details/')}}/@if(isset($data->userId))
								{{ $data->userId}}
								@endif" title="user details"><i class="fa fa-user-secret"></i>
							</a>
						@endif
					@endif
                   </td>
                </tr>
                	@endforeach
                @endif
                </tbody>
                <!--<tfoot>
                  <tr>
                  <th>Name</th>
                  <th>E-mail</th>
                  <th>Type</th>
                  <th>Gender</th>
                  <th>Last Logged</th>
                  <th>Created On</th>
				  <th>Action</th>
                </tr>
                </tfoot>-->
              </table>
            </div>
			</div>
            <!-- /.box-body -->
                </div>
                  </div>
<script>

	$(function(){
		$('#example1').DataTable( {
			"aaSorting": [[ 0, "desc" ]],
			"aoColumnDefs" : [{
		   		'bSortable' : false,
		   		'aTargets' : [ 6 ]
		 	}]
    	});
   });

  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
@endsection


