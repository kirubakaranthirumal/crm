@extends('admin.layouts.master')
@section('content')
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
<script language="javascript">
		(function($,W,D){
			var JQUERY4U = {};

			$.validator.addMethod(
				  "notEqualTo",
				  function(elementValue,element,param) {
					return elementValue != param;
				  },
				  "Value cannot be {0}"
			);

			JQUERY4U.UTIL =
			{
				setupFormValidation: function()
				{
					//form validation rules
					$("#ticket-form").validate({
						rules: {
							email: "required",
							 old_password:"required",
							new_password: "required"
						},
						messages: {
							email: "Please enter your email address",
							old_password:"Please enter your old password",
							new_password: "Please enter your new password"
						},
						submitHandler: function(form){
							form.submit();
						}
					});
				}
			}
			//when the dom has loaded setup form validation rules
			$(D).ready(function($) {
				JQUERY4U.UTIL.setupFormValidation();
			});

		})(jQuery, window, document);
	</script>
<style>
	#ticket-form label.error{
	    color: #FB3A3A;
	    display: inline-block;
	    //margin: 4px 0 5px 125px;
	    padding: 0;
	    text-align: left;
	    width: 250px;
	}

	.form-control{
		background-color: #fff;
		background-image: none;
		border: 1px solid #ccc;
		border-radius: 4px;
		box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
		color: #555;
		display: block;
		font-size: 14px;
		height: 34px;
		line-height: 1.42857;
		padding: 6px 12px;
		transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
		width: 96%;
	}
</style>
    <section class="content">
		<div class="row">
			<!-- left column -->
	
			<div class="col-md-12">
				@if (session('ChangePasswordSuccess'))
					<div class="flash-message">
						 <div class="alert alert-success">
							Password Changed successfully
							         <!--  <script>
              window.setTimeout(function(){
window.location.href = "{{asset('/admin/change_password/')}}";
               }, 1000);
             </script>-->
						</div>
					</div>
				@endif
				@if (session('ChangePasswordError'))
					<div class="flash-message">
						 <div class="alert alert-danger">
							Unable to Change Password
						</div>
					</div>
				@endif
				<!-- general form elements -->
				
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Change Password</h3>
					</div><!-- /.box-header -->
					<div class="box-body">
					
						<!-- form start -->
						<form action="" method="PUT" id="ticket-form" class="form-horizontal" novalidate="novalidate">
							<div class="col-md-8">
								<input type="hidden" name="_token" value="{{ csrf_token() }}">
								<div class="form-group">
									<label>Email Address <span id="required">*</span></label>
									<input type="text" name="email" id="email" class="form-control" placeholder="Enter Your Email">
								</div>
								<div class="form-group">
									<label>Old Password <span id="required">*</span></label>
									<input type="password" name="old_password" id="old_password" class="form-control" >
								</div>
								<div class="form-group">
									<label>New Password <span id="required">*</span></label>
									<input type="password" name="new_password" id="new_password" class="form-control" >
								</div>
								
							</div>
						</div><!-- /.box-body -->
						<div class="box-footer">
							<input type="submit" name="submit"  value="Change Password" class="btn btn-primary">
						</div>
					</form>
					<div style="clear:both">&nbsp;</div>
				</div>
			</div>
			
		</div>
	</div>
</section>
@endsection


