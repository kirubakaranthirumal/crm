@extends('admin.layouts.master')

@section('content')
             <section class="invoice">
          <!-- title row -->
          <div class="row">
            <div class="col-xs-12">
				<!--<div style="float:right;margin-right:1%;">
					<a href="{{asset('/admin/edit_ticket/')}}/@if(isset($ticketdata->ticketId)){{$ticketdata->ticketId}}@endif" class="btn btn-primary">
						Edit Ticket
					</a>
				</div>-->
              <h2 class="page-header">
               <i class="fa fa-ticket" aria-hidden="true"></i> <span><b>Feedback ID :</b>
               <?php
              // print"<pre>";
               //print_r($historydata);
              // exit;
               ?>
               @if(isset($feedlist->feed_id))
                  {{$feedlist->feed_id}}
               @endif
        </span>
                  <!--<div class="pull-right" style="margin-right:16px;">

                  <a class="btn btn-success" href="">Edit Ticket</a>

                   <!--<a class="btn btn-success" href="{{ url(config('quickadmin.route').'/dept_transfer') }}">Dept Transfer</a>
                  </div>-->

              </h2>



            </div><!-- /.col -->

          </div>
          <!-- info row -->
          <div class="row invoice-info">
            <div class="col-sm-6 invoice-col">

              <div style="border:0px solid red;width:100%;float:left;">
                <div style="border:0px solid red;width:18%;float:left;">
                <b>Name</b>
              </div>
              <div style="border:0px solid red;width:3%;float:left;">
                <b>:</b>
              </div>
              <div style="border:0px solid red;width:65%;float:left;">
                <span>
                  @if(isset($feedlist->feed_user_name))
                    {{$feedlist->feed_user_name}}
                  @endif
                </span>
              </div>
             </div>
             <div style="border:0px solid red;width:100%;float:left;">
                <div style="border:0px solid red;width:18%;float:left;">
                <b>Email </b>
              </div>
              <div style="border:0px solid red;width:3%;float:left;">
               <b> :</b>
              </div>
              <div style="border:0px solid red;width:65%;float:left;">
                <span>
                   @if(isset($feedlist->feed_email))
                    {{$feedlist->feed_email}}
                  @endif
                </span>
              </div>
             </div>

                <div style="border:0px solid red;width:100%;float:left;">
                <div style="border:0px solid red;width:18%;float:left;">
                <b>Mobile No </b>
              </div>
              <div style="border:0px solid red;width:3%;float:left;">
                <b>:</b>
              </div>
              <div style="border:0px solid red;width:65%;float:left;">
                <span>
                  @if(isset($feedlist->feed_mobile))
                    {{$feedlist->feed_mobile}}
                  @endif
                </span>
              </div>
             </div>
              <div style="border:0px solid red;width:100%;float:left;">
              <div style="border:0px solid red;width:18%;float:left;">
                <b>Subject </b>
              </div>
              <div style="border:0px solid red;width:3%;float:left;">
                <b>:</b>
              </div>
              <div style="border:0px solid red;width:65%;float:left;">
                <span>
                @if(isset($feedlist->feed_subject))
                    {{$feedlist->feed_subject}}
                  @endif
                </span>
              </div>
             </div>
            </div><!-- /.col -->
    <!-- /.col -->
            <div class="col-sm-6 invoice-col">
              <div style="border:0px solid red;width:100%;float:left;">
              <div style="border:0px solid red;width:18%;float:left;">
                <b>Type </b>
              </div>
              <div style="border:0px solid red;width:3%;float:left;">
                <b>:</b>
              </div>
              <div style="border:0px solid red;width:65%;float:left;">
                <span>
                   @if(isset($feedlist->feed_type))
						@if($feedlist->feed_type==1)
							General Feedback
						@elseif($feedlist->feed_type==2)
							Ticket Feedback
						@endif
                  @endif
                </span>
              </div>
             </div>
       
            <div style="border:0px solid red;width:100%;float:left;">
              <div style="border:0px solid red;width:18%;float:left;">
                <b>Created On </b>
              </div>
              <div style="border:0px solid red;width:3%;float:left;">
                <b>:</b>
              </div>
              <div style="border:0px solid red;width:65%;float:left;">
                <span>

              @if(isset($feedlist->feed_created_on))
                   <?php
                          $date=date_create($feedlist->feed_created_on);
                          echo date_format($date,"Y-m-d h:i A");
                          ?>
              @endif
                </span>
              </div>
             </div>
            </div><!-- /.col -->
                      </div><!-- /.row -->
					  <br>
         <div class="row invoice-info">
            <!-- left column -->
              <div class="col-sm-12 invoice-col">
              <!-- general form elements -->
                  
            <div style="border:0px solid red;width:100%;float:left;">
              <div style="border:0px solid red;width:8.8%;float:left;">
                <b>Description </b>
              </div>
				<br>
              <div style="border:0px solid red;width:70%;float:left;">
                <span>

                @if(isset($feedlist->feed_desc))
                    {{$feedlist->feed_desc}}
                  @endif
                </span>
              </div>
             </div><!-- /.box -->
              </div>


          </div><!-- /.row -->
          </div>
          </section>


@endsection