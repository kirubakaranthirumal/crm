@extends('admin.layouts.master')
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
<script language="javascript">
	(function($,W,D){
	    var JQUERY4U = {};

	    $.validator.addMethod(
			  "notEqualTo",
			  function(elementValue,element,param) {
				return elementValue != param;
			  },
			  "Value cannot be {0}"
        );

	    JQUERY4U.UTIL =
	    {
	        setupFormValidation: function()
	        {
	            //form validation rules
	                $("#contentmanage-form").validate({
	                rules: {
	                    mail_app_id: "required",
						mail_user_id:"required",
						mail_user_password:"required",
						mail_desc:"required",
						mail_status:{
							required: true,
							notEqualTo: 3
						}
	                },
	                messages: {
						mail_app_id: "Please select menu app",
	                    mail_user_id: "Please enter user name",
						mail_user_password: "Please enter password",
						mail_desc: "Please enter mail desc",
						mail_status: "Please select status"
	                },
	                submitHandler: function(form){
	                    form.submit();
	                }
	            });
	        }
	    }

	    //when the dom has loaded setup form validation rules
	    $(D).ready(function($) {
	        JQUERY4U.UTIL.setupFormValidation();
	    });

	})(jQuery, window, document);
</script>
<style>
	#contentmanage-form label.error{
	    color: #FB3A3A;
	    display: inline-block;
	    //margin: 4px 0 5px 125px;
	    padding: 0;
	    text-align: left;
	    width: 250px;
	}

	#category-form label.error{
		color: #FB3A3A;
		display: inline-block;
		//margin: 4px 0 5px 125px;
		padding: 0;
		text-align: left;
		width: 250px;
	}

	#priority-form label.error{
		color: #FB3A3A;
		display: inline-block;
		//margin: 4px 0 5px 125px;
		padding: 0;
		text-align: left;
		width: 250px;
	}

	#source-form label.error{
		color: #FB3A3A;
		display: inline-block;
		//margin: 4px 0 5px 125px;
		padding: 0;
		text-align: left;
		width: 250px;
	}

	#type-form label.error{
		color: #FB3A3A;
		display: inline-block;
		//margin: 4px 0 5px 125px;
		padding: 0;
		text-align: left;
		width: 250px;
	}

	.form-control{
		background-color: #fff;
		background-image: none;
		border: 1px solid #ccc;
		border-radius: 4px;
		box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
		color: #555;
		display: block;
		font-size: 14px;
		height: 34px;
		line-height: 1.42857;
		padding: 6px 12px;
		transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
		width: 96%;
	}
</style>


<script type="text/javascript" language="javascript">
    $(document).ready(function(){
    	//$("#modal-container-department").dialog({modal: true});
    });
</script>
@section('content')
    <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
				@if(session('contentManageUpdSuc'))
					<div class="flash-message">
						<div class="alert alert-success">
							Mail Account Setting Updated Successfully
							<script language="javascript">
								window.setTimeout(function(){window.location.href = "{{asset('/admin/mailaccsettings/')}}";}, 1000);
							</script>
						</div>
					</div>
				@endif

				<div class="col-md-12">
					<!-- general form elements -->
					<div class="box box-primary">
						<div class="box-header with-border">
							<h3 class="box-title">Mail Account Settings</h3>
						</div><!-- /.box-header -->

							<div class="box-body">
								<!--<a id="modal-department" href="#modal-container-department" role="button" class="btn btn-primary" data-toggle="modal">Add DepartMent</a>-->

									<form action="" method="PUT" id="contentmanage-form" novalidate="novalidate">
										<input type="hidden" name="_token" value="{{ csrf_token() }}">
										<!--<input type="hidden" name="settings_type" id="settings_type" value="1">-->
										<div class="box-body">
													<div class="form-group">
															<label>Application</label>&nbsp;<span id="required">*</span>
															<select class="form-control" name="mail_app_id" id="mail_app_id" onchange="load_event(this.value)" tabindex="1">
																<option value="">Select Application</option>
																	@if(isset($app_data))
																		@foreach ($app_data as $data)
																			@if((isset($data->appId)) && (isset($data->appName)))
																				<?php
																					$mailaccset_sel="";
																				?>
																				@if((!empty($data->appId)) && (!empty($mailAccSetVal['mailAppId'])))
																					@if($data->appId == $mailAccSetVal['mailAppId'])
																						<?php $mailaccset_sel="selected"; ?>
																					@endif
																				@endif
																				<option value="{{$data->appId}}" <?=$mailaccset_sel?>>{{$data->appName}}</option>
																			@endif
																		@endforeach
																	@endif
															</select>
														</div>
												<div class="form-group">
													<label>User Name</label>&nbsp;<span id="required">*</span>
													<input type="text" placeholder="User Name" name="mail_user_id" id="mail_user_id" class="form-control" value="<?=(!empty($mailAccSetVal['mailUserId'])?$mailAccSetVal['mailUserId']:"")?>">
											    </div>
												<div class="form-group">
													<label>Password</label>&nbsp;<span id="required">*</span>
													<input type="text" placeholder="Password" name="mail_user_password" id="mail_user_password" class="form-control" value="<?=(!empty($mailAccSetVal['mailUserPassword'])?$mailAccSetVal['mailUserPassword']:"")?>">
												</div>
												<!--<div class="form-group">
													<label>Description</label>&nbsp;<span id="required">*</span>
													<textarea placeholder="Description" name="mail_desc" id="mail_desc" class="form-control"><?=(!empty($mailAccSetVal['mailDesc'])?$mailAccSetVal['mailDesc']:"")?></textarea>
												</div>-->
												<div class="form-group">
													<label>Description <!--<span id="required">*</span>--></label>
													<script src="{{asset('/ckeditor_4.5.9_full/ckeditor.js')}}"></script>
													<script src="{{asset('/ckeditor_4.5.9_full/samples/js/sample.js')}}"></script>
													<textarea class="form-control" rows="5" cols="45" name="editor" id="editor" tabindex="12" ><?=(!empty($mailAccSetVal['mailDesc'])?$mailAccSetVal['mailDesc']:"")?></textarea>
													<script>
														initSample();
													</script>
												</div>
												<div class="form-group">
													<label>Status</label>
													<br>
													<?php
														$active_checked="";
														$inactive_checked="";
														if(!empty($mailAccSetVal['mailStatus'])){
															if($mailAccSetVal['mailStatus']==1){
																$active_checked="checked";
																$inactive_checked="";
															}
															elseif($mailAccSetVal['mailStatus']==2){
																$active_checked="";
																$inactive_checked="checked";
															}
														}
														else{
															$active_checked="";
															$inactive_checked="checked";
														}
													?>
													<input type="radio" name="mail_status" id="mail_status" value="1" <?=(!empty($active_checked)?$active_checked:"")?>> Active
													<input type="radio" name="mail_status" id="mail_status" value="2" <?=(!empty($inactive_checked)?$inactive_checked:"")?>> In-Active
												</div>
											</div>
										<div class="box-footer">
											<input type="submit" name="submit" name="submit" value="Submit" class="btn btn-primary">
										</div>
									</form>

								<div style="clear:both;"></div>
										<table id="department" class="table table-bordered table-hover">
									<thead>
										<tr>
											<th>Application Name</th>
											<th>User Name</th>
											<th>Status</th>
											<th>Created On</th>
											<th>Action</th>
										</tr>
									</thead>

									<tbody>
										@if(isset($mailAccSetArray))
											@foreach($mailAccSetArray as $mail_acc_set_data)
												<tr>
													<td>
														@if(isset($mail_acc_set_data['mailAppName']))
															{{$mail_acc_set_data['mailAppName']}}
														@endif
													</td>
													<td>
														@if(isset($mail_acc_set_data['mailUserId']))
															{{$mail_acc_set_data['mailUserId']}}
														@endif
													</td>
													<td>
														@if(isset($mail_acc_set_data['mailStatus']))
															@if($mail_acc_set_data['mailStatus']==1)
																Active
															@elseif($mail_acc_set_data['mailStatus']==2)
																In-Active
															@endif
														@endif
													</td>
													<td>
														@if(isset($mail_acc_set_data['createdOn']))
														<?php
															$date=date_create($mail_acc_set_data['createdOn']);
															echo date_format($date,"Y-m-d h:i A");
														?>
														@endif
													</td>
													<td>
														@if(isset($mail_acc_set_data['mailId']))
															{!!HTML::linkRoute('admin.mailaccsettings.edit','',array($mail_acc_set_data['mailId']), array('title'=>'edit', 'class'=>'fa fa-edit'))!!}

															<a href="{{asset('/admin/del_mail/')}}/@if(isset($mail_acc_set_data['mailId'])){{ $mail_acc_set_data['mailId']}} @endif" title="delete">
																<i class="fa fa-remove"></i>
															</a>
														@endif
													</td>
												</tr>
											@endforeach
										@endif
									</tbody>
								</table>
						</div><!-- /.box-body -->
					</div><!-- /.box -->
				</div><!-- /.box -->
	</section>

	<script language="javascript">

		$(function() {

		$('#department').DataTable( {
			"aaSorting": [[ 3, "desc" ]],
			 "aoColumnDefs" : [
				 {
				   'bSortable' : false,
				   'aTargets' : [ 4 ]
				 }]
			} );
		} );
	</script>


@endsection


